#include <pthread.h>
#include "common.h"
#include "1_util.h"
#include "2_threadserver_handle.h"


int main(int argc, char *argv[])
{
	register_tcp_handlers();

	prepare_generic_socket(argc, argv, AF_INET, AI_PASSIVE, SOCK_STREAM, IPPROTO_TCP);

	if (listen(sock, 1) < 0)
	{
		exit_with_error("listen failed");
	}

	receive_multi_tcp_clients();

	cleanup();

	return 0;
}

