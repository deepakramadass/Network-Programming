#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <assert.h>
#include "2_threadserver_handle.h"

void connected_mode(FILE *tx, FILE *rx, int client, char username[])
{
connect_mode:;
	char *buffer = NULL; 
	size_t len = 0;
	int timer = 0;
	char email_port[] = "10691";
	char dropbox_port[] = "10692";
	char *port = NULL;
	buffer = "Choose one of the following:\n";
	ssize_t bytes_received = strlen(buffer); 
	send_tcp_data(rx, tx, buffer, bytes_received);
	buffer = NULL;
	buffer = "Email\tDropbox\n";
	bytes_received = strlen(buffer); 
	send_tcp_data(rx, tx, buffer, bytes_received);
	buffer = NULL;
	int trial = 0;
read_data:bytes_received = getline(&buffer, &len, rx);

	if (bytes_received < 0 && errno != EINTR)
	{
		goto close;
	}

	if (bytes_received > 0 || errno == EINTR)
	{
		while (bytes_received == 0 && errno == EINTR)
		{
			printf("getline got EINTR, re-attempting\n");
			bytes_received = getline(&buffer, &len, rx);
		}
		buffer[bytes_received] = '\0';

		if ((bytes_received == 1) && (buffer[bytes_received] = '\0'))
		{
			char display_3[] = "Invalid Input. Try again\n";
			send_tcp_data(rx,tx,display_3,25);
			goto read_data;
		}
		char message[MAXLENGTH];
		int i =0;
		for (i=0;buffer[i+1]!='\0';i++)
		{
			message[i] = buffer[i];
		}
		message[i]='\0';

		if (trial == 0)
		{
			if (strcmp(message,"Email") == 0)
			{
				port = email_port;
			}
			else if (strcmp(message,"Dropbox") == 0)
			{
				port = dropbox_port;
			}
			else if (strcmp(message,"Quit") == 0)
			{
				goto close;
			}
			else
			{
				timer++;
				if (timer <= 5)
				{
					char display_1[] = "Invalid option. Try Again\n";
					send_tcp_data(rx, tx, display_1, 27);
					goto read_data;
				}
				else
				{
					char display_2[] = "You have exceeded maximum number of attempts. Goodbye!\n";
					send_tcp_data(rx, tx, display_2, 56);
					goto close;
				}
			}
	
			int initiate = 0;
			initiate = initialize_client(port);

			if (initiate == 1)
			{
				char display_4[] = "Sorry! Email or Dropbox program unavailable\n";
				send_tcp_data(rx, tx, display_4,33);
				goto close;
			}
			int status_username = 0;
			status_username = query_email_or_dropbox(message,port,username,trial,rx,tx);
			if (status_username == 2)
			{
				printf("got status 2 after sending username\n");
				goto close;
			}
			else
			{
				;
			}
		}
		else
		{
			if (strcmp(message,"Quit") == 0)
				goto close;
			int status = 0;
			status = query_email_or_dropbox(message,port,username,trial,rx,tx);
			if ((status == 2) ||(status == 3))
			{
				//printf("control connect received status = %d\n",status);
				goto connect_mode;
			}
			else if (status == 1)
				goto close;
			else 
				;
		}
		trial++;
	}
	goto read_data;


close:
	if (bytes_received <= 0)
	{
		printf("client closed the connection!\n");
	}
	if (buffer != NULL)
	{
		free(buffer);
	}
	return;
}
