/* Uses threads to handle multiple simultaneous clients */
//run with port # as the first argument
//talk to using netcat, e.g.:
//nc 127.0.0.1 10689
//supports multiple concurrent TCP clients

#include <pthread.h>
#include "common.h"
#include "1_util.h"
#include "2_threadserver_handle.h"

#define MAXKIDS 10
int stop = 0;
int sock = 0;
struct addrinfo *listen_addr = NULL;
char *output = NULL;
int children = 0;
int total_children = 0;
pthread_t mychildren[MAXKIDS] = { 0 };
char lastmsg[MAXLENGTH] = { '\0' };

void register_tcp_handlers()
{
	struct sigaction actinfo;
	actinfo.sa_handler = handler2;
	sigfillset(&actinfo.sa_mask); //todo check for error
	actinfo.sa_flags = 0;
	sigaction(SIGINT, &actinfo, 0); //todo check for error
	sigaction(SIGHUP, &actinfo, 0); //todo check for error
	sigaction(SIGTERM, &actinfo, 0); //todo check for error
	actinfo.sa_handler = SIG_IGN;
	sigaction(SIGPIPE, &actinfo, 0); //todo check for error
}

void prepare_generic_socket(int argc, char *argv[], 
		int family, int flags, int type, int protocol)
{
	struct addrinfo lookup_addr;
	memset(&lookup_addr, 0, sizeof(struct addrinfo));
	lookup_addr.ai_family = family; 
	lookup_addr.ai_flags = flags;
	lookup_addr.ai_socktype = type;
	lookup_addr.ai_protocol = protocol;

	if (getaddrinfo(NULL, argv[1], &lookup_addr, &listen_addr) != 0)
	{
		exit_with_error("getaddrinfo failed");
	}

	sock = socket(listen_addr->ai_family, listen_addr->ai_socktype,
			listen_addr->ai_protocol);
	if (sock < 0)
	{
		exit_with_error("socket failed");
	}
	if (bind(sock, listen_addr->ai_addr, 
				listen_addr->ai_addrlen) < 0)
	{
		exit_with_error("bind failed");
	}

}

//this function sends a generic data buffer via tcp
void send_tcp_data(FILE* rx, FILE *tx, void *data, int datalen)
{
	if (tx)
	{
		size_t bytes_sent = fwrite(data, 1, datalen, tx);
		if (errno == EPIPE)
		{
			errno = 0;
			fclose(tx);
			fclose(rx);
			exit_with_error("pipe error\n");
		}
		else if (bytes_sent < 0)
		{
			fclose(tx);
			fclose(rx);
			exit_with_error("send failed");
		}
		fflush(tx);
	}
	else
	{
		sprint_hex(data, datalen);
	}
}

void join_all_children()
{
	int children_to_join = total_children;
	while (children_to_join)
	{
		int i;
		for (i = 0; i < MAXKIDS; i++)
		{
			if (mychildren[i] != 0)
			{
				pthread_join(mychildren[i], NULL);
				children_to_join--;
				printf("Child closed I now have %d "\
						"kids left to join\n", 
					children_to_join);
			}
		}
	}
}

void receive_multi_tcp_clients()
{
	while (!stop)
	{
		struct sockaddr_storage client_addr;
		socklen_t addr_len = sizeof(struct sockaddr_storage);

		int client = accept(sock, 
					(struct sockaddr *) &client_addr,
					&addr_len);
		if (stop)
		{
			break;
		}

		if (errno == EINTR && client < 0)
		{
			printf("accept got EINTR, re-attempting\n");
			continue;
		}

		if (client < 0)
		{
			exit_with_error("accept failed");
		}

		int *arg = malloc(sizeof(int));
		*arg = client;
		int result = pthread_create(&mychildren[total_children],
				NULL, handle_tcp_client, arg);
		if (result != 0)
		{
			exit_with_error("pthread_create failed");
		}

		total_children++;
		children++;
		printf("started child thread I now have %d kids and I had %d\n", 
				children, total_children);
		if (children == MAXKIDS)
		{
			break;
		}
	}

	join_all_children();
}

