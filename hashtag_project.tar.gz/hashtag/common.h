#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>

#define MAXLENGTH 2000

/**
  * This struct is used to pass information between all the programs 
  * in the system
  * code = 3 -- corresponds to information conserning the user (ex. username)
  * code = 4 -- corresponds to all infromation to and from the email program
  * code = 5 -- corresponds to all infromation to and from the drive program
  */ 
struct data{
	uint8_t code;		///< used to identity the type of data
	int64_t len;		///< holds the length of the corresponding message
        char msg;		///< points to the start of the message
} __attribute__((packed)); 

/**
  * This structs is used to hold information about each user
  */
struct users{
	int8_t online;		///< used to check if the user is online
  	char username[10]; 	///< points to the user name
	char password[10];		///< holds the hash value of the user's password
} __attribute__((packed));

/**
  * This struct is used for storing and viewing email information
  */
struct email{
	char to[10];		///< the user the mail is addressed to
	char from[10];		///< the user that originates the mail
	char subject[100];	///< subject of the mail
	char msg[2000];		///< body of the mail
}__attribute__((packed));

int server_id;
int initialize();
int client_func(char *user,int option);
int initialize_client(char *port);
void close_up();
int check_user(struct data *recv, FILE *rx);
int get_message(FILE *rx);
int check_inbox(FILE *rx,FILE *tx);
int compose_mail(FILE *rx, FILE *tx);
#endif
