#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "2_threadserver_handle.h"
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>

FILE *tx = NULL;
FILE *rx = NULL;
struct addrinfo *send_addr;

int initialize_client(char *port)
{
	struct addrinfo lookup_addr;
	memset(&lookup_addr, 0, sizeof(struct addrinfo));
	lookup_addr.ai_family = AF_UNSPEC;
	lookup_addr.ai_socktype = SOCK_STREAM;
	lookup_addr.ai_protocol = IPPROTO_TCP;

	struct addrinfo *send_addr;
	if (getaddrinfo("127.0.0.1", port, &lookup_addr, &send_addr) != 0)
	{
		#ifdef DEBUG
		perror("getaddrinfo failed");
		#endif
		printf("getaddrinfo has failed\n");
		return 1;
	}

	int sock = socket(send_addr->ai_family, send_addr->ai_socktype,
			send_addr->ai_protocol);
	if (sock < 0)
	{
		#ifdef DEBUG
		perror("socket failed");
		#endif
		printf("socket has failed\n");
		return 1;
	}

	if (connect(sock, send_addr->ai_addr, send_addr->ai_addrlen) < 0)
	{
		#ifdef DEBUG
		perror("connect failed");
		#endif
		printf("connect has failed\n");
		return 1;
	}

	tx = fdopen(sock, "w");
	rx = fdopen(dup(sock),"r");

	return 0;
}

int query_email_or_dropbox(char message[] ,char *port,char username[],int trial, FILE *rx_client, FILE *tx_client)
{	
	char *email_port = "10691";
	char *dropbox_port = "10692";
	uint64_t datalen = 0;
	struct data *tosend = NULL;
	//int status = 0;
	if (trial == 0)
	{
		printf("username is %d bytes\n",strlen(username));
		datalen = sizeof(struct data) + strlen(username) - 1;
        	tosend = malloc(datalen);
		tosend->code = 3;
		tosend->len = strlen(username);
		strncpy(&(tosend->msg),username,strlen(username));
	}
	else 
	{
		datalen = sizeof(struct data) + strlen(message) - 1;
		tosend = malloc(datalen);
		if (strcmp(port,email_port) == 0)
		{
			tosend->code = 4;
		}
		else if (strcmp(port,dropbox_port) == 0)
		{
			tosend->code = 5;
		}
		else
		{
			printf("received incorrect port no\n");
		}
		tosend->len = strlen(message);
		strncpy(&(tosend->msg),message,strlen(message));
	}
	
	size_t bytes_sent = fwrite(tosend,1,datalen,tx);
	
	if(bytes_sent != (datalen))
	{
	       	#ifdef DEBUG 
	       	perror("sendto failed");
	       	#endif
		printf("fwrite failed\n");
	        free(tosend);
        	return 1;
	}
	fflush(tx);

        struct data *torecv = malloc(sizeof(struct data));
	size_t bytes_received = fread(torecv,1,sizeof(struct data)-1,rx);

	if ((bytes_received < 0)&&(errno != EINTR))
	{
		fclose(tx);
		fclose(rx);
		printf("fread failed\n");
		close_up();
	}

	while ((bytes_received > 0))
	{
		if ((bytes_received == 0) && (errno != EINTR))	
		{
			errno = 0;
			printf("fread got EINTR, re-attempting\n");
			close_up();
			return 3;
		}
		if ((bytes_received == 0) && (errno = EINTR))	
		{
			errno = 0;
			printf("fread got EINTR, re-attempting\n");
			close_up();
			return 2;
		}

		if (torecv->code == 4)
		{
			printf("msg received from email server\n");
		}
		else if (torecv->code == 5)
		{
			printf("msg received from dropbox server\n");
		}
		else
		{
			printf("invalid code received\n");
			close_up();
		}
		
		uint64_t recv_len = torecv->len;
		
		char *received_string = malloc(recv_len + 1);
		bytes_received = fread(received_string,1,recv_len,rx);
		received_string[recv_len] = '\0';
		
		if (bytes_received != recv_len)
		{
			printf("wrong size of received string\n");
			close_up();
		}
		else if ((bytes_received == 1) && atoi(received_string) == 1)
		{
			return 0;
		}
		else
		{
			send_tcp_data(rx_client,tx_client,received_string,recv_len+1);
			bytes_received = fread(torecv,1,sizeof(struct data)-1,rx);
		}
	}
	return 0;
}

void close_up()
{
	freeaddrinfo(send_addr);
	fclose(tx);
	fclose(rx); 
}
