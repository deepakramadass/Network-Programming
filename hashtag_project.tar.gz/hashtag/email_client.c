//author Deepak Ramadass
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#include "common.h"

#define MAXLENGTH 2000

FILE *tx = NULL;
FILE *rx = NULL;
struct addrinfo *send_addr = NULL;

int initialize(){

	char *IP = "127.0.0.1";
	char *sock_add = "10690";
	struct addrinfo lookup_addr;
	memset(&lookup_addr, 0, sizeof(struct addrinfo));
	lookup_addr.ai_family = AF_UNSPEC;
	lookup_addr.ai_socktype = SOCK_STREAM;
	lookup_addr.ai_protocol = IPPROTO_TCP;
	
	if (getaddrinfo(IP,sock_add, &lookup_addr, &send_addr) != 0)
	{
		perror("getaddrinfo failed");
		return 1;
	}

	int sock = socket(send_addr->ai_family, send_addr->ai_socktype,
			send_addr->ai_protocol);
	if (sock < 0)
	{
		perror("socket failed");
		return 1;
	}

	if (connect(sock, send_addr->ai_addr, send_addr->ai_addrlen) < 0)
	{
		perror("connect failed");
		return -1;
	}

	tx = fdopen(sock, "w");
	rx = fdopen(dup(sock),"r");

	server_id = 4;	
	fwrite(&server_id,1,4,tx);

	return 0;

}

/*
void close_up(struct addrinfo *send_addr,FILE *rx,FILE *tx){
	freeaddrinfo(send_addr);
	fclose(tx);
	fclose(rx); 
}
*/

void close_up(){
	freeaddrinfo(send_addr);
	fclose(tx);
	fclose(rx); 
}
//run with ip and port as arguments
//talk to using netcat, e.g.:
//nc -l -k -v 127.0.0.1 10689
//nc -l -k -v ::1 10689
int client_func(char *user, int option)
{

	size_t len = sizeof(struct data) + strlen(user)-1;
	struct data *tosend = malloc(len);
	tosend->code = 4;
	tosend ->len = strlen(user);
	strncpy(&(tosend->msg),user,tosend->len);
	size_t bytes_sent = fwrite(tosend, 1, len, tx);
	if (bytes_sent != (len))
	{
		printf("%d\n", bytes_sent);
		perror("fwrite 1 failed");
		fclose(tx);
		return 1;
	}

	fflush(tx);
	free(tosend);

	struct data *recv = malloc(sizeof(struct data));
	size_t bytes_received = fread(recv,1,sizeof(struct data)-1,rx);

	if (bytes_received == 0 && errno == EPIPE )
	{
		errno = 0;
		perror("fread 2 failed");
		free(recv);
		fclose(rx);
		fclose(tx);
		return 1;
	} 

	if(recv->code !=4){
		free(recv);
		fclose(rx);
		fclose(tx);
		return 1;
	}
	
	char *temp = malloc(recv->len + 1);
    	bytes_received = fread(temp,1,(recv->len),rx); 
			
	if (bytes_received == 0 && errno == EPIPE )
	{
		errno = 0;
		perror("fread 2 failed");
		free(recv);
		fclose(rx);
		fclose(tx);
		return 1;
	}
	temp[recv->len] = '\0';

	if(atoi(temp) != 1){
		free(recv);
		fclose(rx);
		fclose(tx);
		return 1;
	}
	free(temp);
//	freeaddrinfo(send_addr);
//	fclose(tx);
//	fclose(rx); 
	
	return 0;
}
