#include "1_util.h"
#include "2_threadserver_handle.h"
#include <stdio.h>
#include <string.h>
#include "common.h"
#include "drive.h"
//creating database
struct users Deepak = {0, .username = "deepak", .password = "deepak"};
struct users Deepika = {0,.username = "deepika", .password = "deepika"};
struct users Pooja = {0,.username = "pooja", .password = "pooja"};
struct users Justin = {0,.username = "justin", .password = "justin"};


char user_list[4][10] = {"deepak","deepika","pooja","justin"};

/*
 *@brief function checks if the user exits in the database
 *@parameter function takes username entered by the user
 *@return function returns 0 if user exits else 1
*/

uint8_t validate_username(char username[])
{
	Deepak.online = 0;
	Deepika.online = 0;
	Pooja.online = 0;
	Justin.online = 0;

	if (strncmp(username,Deepak.username,6) == 0)
	{
		printf("Deepak is online\n");
		Deepak.online = 1;
		return 0;
	}
	else if (strncmp(username,Deepika.username,7) == 0)
	{
		printf("Deepika is online");
		Deepika.online = 1;
		return 0;
	}
	else if (strncmp(username, Pooja.username,5) == 0)
	{
		printf("Pooja is online\n");
		Pooja.online = 1;
		return 0;
	}
	else if (strncmp(username, Justin.username,6) == 0)
	{
		printf("Justin is online");
		Justin.online = 1;
		return 0;
	}
	else
	{
		printf("noone is online\n");
		return 1;
	}
}

/*
 *@brief function checks if the password is correct
 *@parameter function takes username and password entered by the user
 *@return function returns 0 if user exits else 1
*/

uint8_t validate_password(char password[])
{
	if ((Deepak.online == 1) && (strncmp(Deepak.password,password,6) == 0))
	{
		printf("Deepak has been authenticated\n");
		return 0;
	}
	else if ((Deepika.online == 1 ) && (strncmp(Deepika.password,password,7) == 0))
	{
		printf("Deepika has been authenticated\n");
		return 0;
	}
	else if ((Pooja.online == 1 ) && (strncmp(Pooja.password,password,5) == 0)) 
	{
		printf("Pooja has been authenticated\n");
		return 0;
	}
	else if ((Justin.online == 1 ) && (strncmp(Justin.password,password,6) == 0)) 
	{
		printf("Justin has been authenticated\n");
		return 0;
	}
	else
	{ 
		printf("noone is authenticated\n");
		return 1;
	}
}

/**
  * This function verifies if a user is valid or not
  * rx points to the receiving socket
  * tx points to the transmitting socket
  */
int verify_user(FILE *rx, FILE *tx, struct data *recv){
	
	if(recv->code != 4)
		return 1;
	char *store = malloc(recv->len + 1);
	fread(store,1,recv->len,rx);
	store[recv->len] = '\0';
	char present[2] = {'0','\0'};
	int i = 0;
	for(i = 0;i < 3;i++){
		if(strcmp(user_list[i],store) == 0){
			present[0] = '1';
		}
	}
	free(store);
	struct data *tosend = malloc(sizeof(struct data));
	tosend->code = 4;
	tosend->len = strlen(present);
	strcpy(&(tosend->msg),present);
	send_tcp_data(rx,tx,tosend,10);
	free(tosend);
	return 0;
}	


/**
  * This function checks transfer func
  * @param rx points to the receiving socket
  * @param tx points to the transmitting socket
  * @param recvmsg user msg
  * @param username name of the user
  * @param original_dirpath from which the user gets the file
  * @return 0/1 Success/Failure
  */

int check_transfer_func(FILE *tx,FILE *rx,char *recvmsg,char *username,char *original_dirpath)
{
      char splitmsg1[MAXLENGTH] = {0};
      char splitmsg2[MAXLENGTH] = {0};
      char splitmsg3[MAXLENGTH] = {0};
      sscanf(recvmsg,"%s %s %s",splitmsg1,splitmsg2,splitmsg3);
        
        int changedir = chdir(original_dirpath);
        if((changedir == -1) && (errno == ENOTDIR))
        {
                errno = 0;
                printf("Cannot change directory\n");
                return 1;
        }
	char *curworkdir = NULL;
	char buf[PATH_MAX+1];
        curworkdir = getcwd(buf,PATH_MAX+1);
        if(curworkdir != NULL)
        {
        }

        int pathlen1 = strlen(curworkdir) + 1;
        char *dirpath = NULL;
        dirpath = strncat(curworkdir,"/",pathlen1);
	changedir = chdir(dirpath);
        if((changedir == -1) && (errno == ENOTDIR))
        {
                errno = 0;
                printf("Cannot change directory\n");
                return 1;
        }

	curworkdir = getcwd(buf,PATH_MAX+1);
        if(curworkdir != NULL)
        {
        }

	FILE *sendfile = NULL;
        if(strcmp(splitmsg1,"Transfer")==0)
        {      
        sendfile = fopen(splitmsg2,"r");
        	if(sendfile!=NULL)
        	{
        	
        	char tempfile[2000]="";
		while(1)
		{			
        	fread(tempfile,1,2000,sendfile);
        	size_t bytes_sent = fwrite(tempfile, 1,sizeof(tempfile),tx);
        	if (bytes_sent != sizeof(tempfile))
        	{
                	printf("%d\n", bytes_sent);
                	perror("fwrite 1 failed");
                	fclose(tx);
                	return 1;
        	}
		fflush(tx);
		if(feof(sendfile))
        	{
        	break;
        	}
        	}

		}
	fclose(sendfile);
	}
			

return 0;
}



//This function processes the data received by a single client
void *handle_tcp_client(void *arg)
{
	int client = *((int *) arg);
	free(arg);
	FILE *rx = fdopen(client, "r");
	FILE *tx = fdopen(dup(client), "w");

	ssize_t bytes_received = fread(&server_id,1,4,rx);

	if (server_id == 1)	//control program
	{

		struct users *buffer = malloc(sizeof(struct users));
		ssize_t bytes_received = fread(buffer,1,sizeof(struct users),rx);

		if (bytes_received < 0 && errno != EINTR)
		{
			goto close;
		}
		if ((bytes_received < 0) || (bytes_received != sizeof(struct users)))
		{
			fclose (tx);
			fclose (rx);
			exit_with_error ("fread failed");
		}

		if (bytes_received > 0)
		{
			int flag_username = validate_username(buffer->username);
			if (flag_username == 0)
			{
				int flag_pwd = validate_password(buffer->password);
				if (flag_pwd == 0)
				{
					ssize_t bytes_sent = fwrite(&flag_pwd,1,4,tx);
			
					if (bytes_sent != 4)
					{
						fclose (tx);
						fclose (rx);
						exit_with_error ("fwrite failed");
					}
				}
				else
				{
					printf("Password is invalid\n");
					goto close;
				}
			}
			else
			{
				printf("Username is unknown\n");
				goto close;
			}
		}
	}
	else if (server_id == 4)
	{
		struct data *recv = malloc(sizeof(struct data));
		bytes_received = fread(recv,1,sizeof(struct data) -1,rx);

		while(bytes_received > 0){
			printf("here\n");	
		
			printf("email program\n");	//email program
			if(verify_user(rx,tx,recv) != 0)
				goto close;
			
			
			bytes_received = fread(recv,1,sizeof(struct data) -1,rx);
		}
	}
	
	else if (server_id == 5)
	{

		printf("dropbox prgram");	//dropbox program
		//Receiving username
        	struct data *torecv = NULL;
        	torecv = malloc(sizeof(struct data)-1);
        	bytes_received = fread(torecv,1,sizeof(struct data)-1,rx);
        	uint8_t length = 0;
        	length = torecv->len;
		char *recvmsg = malloc(length+1);
		char *username = malloc(length+1);
        	if(fread(recvmsg,1,length,rx) != length)
        	{
        	exit(1);
        	}
        	recvmsg[length] = '\0';
		strcpy(username,recvmsg);


//Receiving Original path
		struct data *torecv1 = NULL; 
                torecv1 = malloc(sizeof(struct data)-1);
		bytes_received = fread(torecv1,1,sizeof(struct data)-1,rx);
		length = torecv1->len;
		char *recvmsg1 = malloc(length+1);
		char *original_dirpath = malloc(length+1);
		if(fread(recvmsg1,1,length,rx) != length)
                {
                exit(1);
                }
                recvmsg1[length] = '\0';
		strcpy(original_dirpath,recvmsg1);
		
//Receivigng recvmsg transfer operation
		struct data *torecv2 = NULL;
                torecv2 = malloc(sizeof(struct data)-1);
		bytes_received = fread(torecv2,1,sizeof(struct data)-1,rx);
		length = torecv2->len;
		char *recvmsg2 = malloc(length+1);
               if(fread(recvmsg2,1,length,rx) != length)
                {
                exit(1);
                }
                recvmsg2[length] = '\0';
		check_transfer_func(tx,rx,recvmsg2,username,original_dirpath);		
		free(torecv);
		free(torecv1);
		free(torecv2);
		free(recvmsg);
		free(recvmsg1);
		free(recvmsg2);
		free(username);
		free(original_dirpath);
	}

	else
	{
		printf("Invalid server id");
		goto close;
	}


close:	if (bytes_received <= 0)
	{
		printf("connection with user management server closed!\n");
	}
	fclose(tx);
	fclose(rx);
	children--;
	printf("now there are %d children\n", children);
	return 0;
}
