#include "common.h"

#ifndef UTIL_H_3
#define UTIL_H_3

extern int stop;
extern int sock;
extern struct addrinfo *listen_addr;
extern char *output;

void sprint_hex(uint8_t *data, size_t length);

void handler2(int signal);

void exit_with_error(char *msg);

void register_handler();

void cleanup();

#endif 
