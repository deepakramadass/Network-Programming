//author Deepak Ramadass
#include "1_util.h"
#include "2_threadserver_handle.h"
#include "common.h"

char *user;
size_t length = sizeof(struct data);
char msg[MAXLENGTH] = "";
char *store = NULL;
ssize_t bytes_received = 0;
struct email *users_email[4][5] = {{NULL}};
int user_num = 0;
int close_client = 0;

/**
  * This function is used to check if the code is 4
  * @param code is the code recieved
  * @return 0/1 success/failure
  */
int code_check(int8_t code){
	if(code != 4)
		return 1;
	else
		return 0;
}

/**
  * This function is used to free memory
  */
void clean_up(){
	int i = 0;
	int j = 0;
	for(i = 0; i< 4;i++){
		for(j = 0; j < 5; j++){
			if(users_email[i][j] != NULL)
				free(users_email[i][j]);
		}
	}
}

/** 
  * This function is used to assign a number to a user
  * @ return num the number assigned
  */
int find_user(char *user){
	int num = 0;

	if(strcmp(user,"deepak") == 0)
		num = 0;
	else if(strcmp(user,"deepika") == 0)
		num = 1;
        else if(strcmp(user,"pooja") == 0)
		num = 2;
        else if(strcmp(user,"justin") == 0)
		num = 3;
	else 
		return -1;

 	return num; 
}

/**
  * This function checks and stores username
  * @param recv points to the recieved data
  * @param rx is used to read the file name
  * @return 0/1 success/failure
  */
int check_user(struct data *recv, FILE *rx){
	if(recv == NULL)
		return 1;
		
	if(recv->code != 3)
		return 1;
	
	//printf("code %d\n",recv->code);
	int64_t user_len = (recv->len);
	//printf("len %lld\n",user_len);
	user = malloc(user_len+1);
	if(fread(user,1,user_len,rx) != user_len)
		return 1;
	user[user_len] = '\0';
	
	if((user_num = find_user(user)) < 0)
		return 1; 
	printf("User %s is logged in\n",user);

	return 0;
}

/**
  * This funtion gets the message from the socket
  * @param rx is used to read data from the control program
  * @return 0/1 success/failure
  */
int get_message(FILE *rx){
	struct data *recv = malloc(length - 1);
 	if(fread(recv,1,length-1,rx) != 9)
		return 1;

	if((recv->code) != 4)
		return 1;
	store = malloc(recv->len + 1);
	if(fread(store,1,recv->len,rx) != recv->len)
		return 1;
	
	store[recv->len] = '\0';	
	free(recv);
	recv = NULL;
	return 0;
}

/**
  * This fuction is used to construct the packet to be sent
  * @param rx is used to read data from the control program
  * @param tx is used to send data to the control program
  * @param msg contains the data to be sent
  * @param tosend points to the response
  */
void send_message(FILE *rx,FILE *tx,char *msg){
	int len = strlen(msg) + sizeof(struct data);
	struct data *tosend = malloc(len);
	tosend->code = 4;
	tosend->len = strlen(msg);
	strncpy(&(tosend->msg),msg,tosend->len);
	//printf("msg %s\n",&(tosend->msg));
	
	send_tcp_data(rx,tx,tosend,len-1);
	free(tosend);
	tosend = NULL;
}
/**
  * This function check if the request is for inbox
  * and display the inbox
  * @param rx is used to read data from the control program
  * @param user holds the user identity
  * @return 0/1 success/failure
  */
int check_inbox(FILE *rx,FILE *tx){
	int i = 0; 
	
	if(users_email[user_num][i] == NULL){
		sprintf(msg,"No Mails\n");
		send_message(rx,tx,msg);
		return 1;
	}

	while((i < 5) && (users_email[user_num][i] != NULL)){

		send_message(rx,tx,"\n\0");	
		sprintf(msg,"No: %d\n",i+1);
		send_message(rx,tx,msg);
		
	/*	sprintf(msg,"To");
		send_message(rx,tx,msg);
		send_message(rx,tx,users_email[user_num][i]->to);
		
		sprintf(msg,"From");
		send_message(rx,tx,msg);
		send_message(rx,tx,users_email[user_num][i]->from);
	*/	
		sprintf(msg,"Subject:");
		send_message(rx,tx,msg);
		send_message(rx,tx,users_email[user_num][i]->subject);
		send_message(rx,tx,"\n\n\0");	
	/*	sprintf(msg,"Message");
		send_message(rx,tx,msg);
		send_message(rx,tx,users_email[user_num][i]->msg);
	*/
		i++;
	}
	sprintf(msg,"Choose one of the following:\nOpen  Delete  Quit\n");
	send_message(rx,tx,msg);	
	send_message(rx,tx,"1");
	 return 0;		
}

/**
  * This function is used to write mails
  * @param rx is used to read data from the control program
  * @param tx is used to send data to the control program
  * @param recv points to the recieved data
  * @return 0/1 success/failure
  */
int compose_mail(FILE *rx, FILE *tx){
			
here:	sprintf(msg,"Send To:");
	send_message(rx,tx,msg);
	send_message(rx,tx,"1");
	
	if(get_message(rx) != 0)
		return 1;
	
	int send_user = find_user(store);
	close_client = initialize();
        close_client = client_func(store,1);		

	if(close_client == 1){
		sprintf(msg,"User Unknown\n");
		send_message(rx,tx,msg);
		goto here;
	}
	
	int i = 0;
	for(i = 0; i < 5; i++){
		if(users_email[send_user][i] == NULL)
			break;
	} 
	
	if(i == 5){
		free(users_email[send_user][0]);
		i = 0;
	}

		
	users_email[send_user][i] = malloc(sizeof(struct email));
	strncpy(users_email[send_user][i]->to,store,strlen(store));
		
	strncpy(users_email[send_user][i]->from,user,strlen(user));

	if(store != NULL);
		free(store);	
		store = NULL;

	sprintf(msg,"Subject:");
	send_message(rx,tx,msg);
	send_message(rx,tx,"1");
	
	if(get_message(rx) != 0)
		return 1;
 	
	strncpy(users_email[send_user][i]->subject,store,strlen(store));
	if(store != NULL);
		free(store);	
		store = NULL;

	sprintf(msg,"Message:");
	send_message(rx,tx,msg);
	send_message(rx,tx,"1");
	
	if(get_message(rx) != 0)
		return 1;

	strncpy(users_email[send_user][i]->msg,store,strlen(store));
	if(store != NULL);
		free(store);	
		store = NULL;
	
	return 0;
} 

/**
  * This funstion displays an email
  * @param rx is used to read data from the control program
  * @param tx is used to send data to the control program
  * @param i refers the email number
  */
void show_mail(FILE *rx, FILE*tx, int i){	
	sprintf(msg,"From: ");
	send_message(rx,tx,msg);
	send_message(rx,tx,users_email[user_num][i]->from);
	send_message(rx,tx,"\n\0");
		
	sprintf(msg,"Subject: ");
	send_message(rx,tx,msg);
	send_message(rx,tx,users_email[user_num][i]->subject);
	send_message(rx,tx,"\n\0");
		
	sprintf(msg,"Message: ");
	send_message(rx,tx,msg);
	send_message(rx,tx,users_email[user_num][i]->msg);	
	send_message(rx,tx,"\n\0");

}
 
/**
  * This function check if the request is for inbox
  * and display the inbox
  * @param rx is used to read data from the control program
  * @param tx is used to send data to the control program
  * @param recv points to the recieved data
  * @return 0/1 success/failure
  */
int manage_inbox(FILE *rx, FILE *tx){
	char *token = strtok(store," ");
	char *temp =  strtok(NULL," ");
	int i = 0;

	if(temp != NULL)
		i = atoi(temp);	

	if(strncmp(token,"Open",strlen("Open")) == 0){
		if((users_email[user_num][i-1] != NULL))
			show_mail(rx,tx,i-1);
		else 
			return 1;

		check_inbox (rx,tx);
		return 0;
	}
	
	else if(strncmp(token,"Delete",strlen("Delete")) == 0){
		if((users_email[user_num][i-1] != NULL)){
			free(users_email[user_num][i-1]);	
			users_email[user_num][i-1] = NULL;
		}
		check_inbox (rx,tx);
		return 0;
	}

	else if(strncmp(token,"Quit",strlen("Quit")) == 0){
		return 2;
	}
	
	else{
		sprintf(msg,"Invalid Entry\n");
		send_message(rx,tx,msg);
		check_inbox (rx,tx);
		return 2;
	}	
	
	return 0;

}

/**
  * This function is used to handle all email operations
  * @param recv points to the recieved data
  * @param tosend points to the response
  * @param rx is used to read data from the control program
  * @param tx is used to send data to the control program
  * @return 0/1 success/failure
  */
int manage_mail(FILE *rx, FILE *tx, struct data *recv,int step){

	if(step == 1){
		sprintf(msg,"Choose one of the following:\nInbox\tCompose\n");
		send_message(rx,tx,msg);	
		step++;
	}

	if(code_check(recv->code) != 0)
		return -1;
	
	if(step == 2){

		int64_t len = recv->len;
		store = malloc(len+1);	

		if(fread(store,1,len,rx) != len)
			return -1;
		store[len] = '\0';
		if(strcmp(store,"Compose") == 0){
			compose_mail(rx,tx);
			step--;
		}
	
		else if(strcmp(store,"Inbox") == 0){

			if(check_inbox (rx,tx) != 0){

				step--;
			}	
			else
				step++;
		}

		else if(strcmp(store,"Quit") == 0)
			return -1;
	
		else{
			sprintf(msg,"Invalid Entry\n");
			send_message(rx,tx,msg);
			send_message(rx,tx,"1");
		}	

		free(store);
		store = NULL;
		return step;
	}		 
		
	if(step == 3){

		int64_t len = recv->len;
		store = malloc(len+1);	

		if(fread(store,1,len,rx) != len)
			return -1;
		//store[len] = '\0';
		
		int catch = manage_inbox(rx,tx);

		if(catch == 1)
			return -1;

		else if(catch == 2){
			step--;
			sprintf(msg,"Choose one of the following:\nInbox\tCompose\n");
			send_message(rx,tx,msg);	
			send_message(rx,tx,"1");
		}
 
		free(store);
		store = NULL;
	}
	//step = 0;
	return step;
}

//This function processes the data received by a single client
void *handle_tcp_client(void *arg)
{
	int client = *((int *) arg);
	free(arg);
	
	int step = 0;
	FILE *rx = fdopen(client, "r");
	FILE *tx = fdopen(dup(client), "w");
	struct data *recv = calloc(1, sizeof(struct data));
	//struct data *tosend = calloc(1,length);
	//struct data *recv = malloc(length);
	bytes_received = fread(recv,1,length-1,rx);

	if (bytes_received < 0 && errno != EINTR)
	{
		goto close;
	}

	

	while (bytes_received >= 0 || errno == EINTR)
	{
		if(bytes_received == 0 && errno == EINTR){
			errno = 0;
			goto close;
		}
	
		if(step == 0){
			if(check_user(recv,rx) != 0)
				goto close;
			else{
				step++;
				goto label1;
			}
		}

		sleep(2);
		
		if((step = manage_mail(rx,tx,recv,step)) < 0){
			//send_message(rx,tx,"quit");
			bytes_received = -1;
			goto close;
		}
		//send_tcp_data(rx, tx, buffer, bytes_received);

	label1:	if(step == 1){
			sprintf(msg,"Choose one of the following:\nInbox\tCompose\n");
			send_message(rx,tx,msg);	
			send_message(rx,tx,"1");
			step++;
		}

		bytes_received = fread(recv,1,length-1,rx);
	}

close:
	if (bytes_received <= 0)
	{
		printf("client closed the connection!\n");
	}
	if (recv != NULL && bytes_received == 0)
	{
		free(recv);
	}

	if (user != NULL && bytes_received == 0){
		free(user);
		user = NULL;
	}

	if(close_client >= 0)
		close_up();
	
	clean_up();	
	fclose(tx);
	fclose(rx);
	children--;
	printf("now there are %d children\n", children);

	return NULL;
}
