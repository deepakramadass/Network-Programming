#include "1_util.h"

//this function prints a generic data buffer to
//the "output" char array (for unit testing)
void sprint_hex(uint8_t *data, size_t length)
{
	char myoutput[MAXLENGTH];
	char tmp[MAXLENGTH];
	assert(length < 100);
	myoutput[0] = '\0';

	int i;
	for (i = 0; i < length; i++)
	{
		sprintf(tmp, "%02x ", data[i]);
		strcat(myoutput, tmp);
		if (i % 16 == 15)
		{
			strcat(myoutput, "\n");
		}
	}
	if (myoutput[strlen(myoutput)-1] != '\n')
	{
		strcat(myoutput, "\n");
	}

	output = strdup(myoutput);
};

void handler2(int signal)
{
	stop = 1;
	if (sock != 0)
	{
		close(sock);
	}
}

void cleanup()
{
	if (listen_addr)
		freeaddrinfo(listen_addr);
	if (sock)
		close(sock); 
}

void exit_with_error(char *msg)
{
	perror(msg);
	cleanup();
	exit(1);
}
