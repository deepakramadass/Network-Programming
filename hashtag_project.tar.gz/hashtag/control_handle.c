#include "1_util.h"
#include "2_threadserver_handle.h"
#include <stdio.h>
#include <string.h>
#include "common.h"

//This function processes the data received by a single client
void *handle_tcp_client(void *arg)
{
	int client = *((int *) arg);
	free(arg);

	char *buffer = NULL;
	size_t len = 0;

	uint8_t flag = 1;

	FILE *rx = fdopen(client, "r");
	FILE *tx = fdopen(dup(client), "w");
	uint8_t no_of_attempts = 0;
	uint8_t count = 0;
	char *username = NULL;
	char *password = NULL;

	buffer = "Username : ";
	ssize_t bytes_received = 11; 
	send_tcp_data(rx, tx, buffer, bytes_received);

read_data:buffer = NULL;
	bytes_received = getline(&buffer, &len, rx);

	if (bytes_received < 0 && errno != EINTR)
	{
		goto close;
	}

	while (bytes_received > 0 || errno == EINTR)
	{
		while (bytes_received == 0 && errno == EINTR)
		{
			printf("getline got EINTR, re-attempting\n");
			bytes_received = getline(&buffer, &len, rx);
		}
		buffer[bytes_received] = '\0';

		if ((bytes_received == 1) && (buffer[0] = '\0'))
		{
			goto error_msg;
		}
		char credential[MAXLENGTH];
		int i =0;
		for (i=0;buffer[i+1]!='\0';i++)
		{
			credential[i] = buffer[i];
		}
		credential[i]='\0';

		int length = strlen(credential);
		if (length > 10)
		{
			char disp_err[] = "Please enter less than or equal to 10 characters\n";
			send_tcp_data(rx,tx,disp_err,strlen(disp_err));
			no_of_attempts++;
			if (no_of_attempts > 5)
			{
				char disp[] = "You have exceeded maximum number of attempts. Goodbye!";
				send_tcp_data(rx,tx,disp,strlen(disp));
				goto close;
			}
			else
			{
				goto read_data;
			}
		}

		if (count == 0)
		{
			username = malloc(sizeof(char *)*(length+1));
			strcpy(username,credential);
			if (username[0]!='\0')
				flag = 0;
			else 
				flag = 1;
		}
		else if ((count == 1)&&(flag == 0))
		{
			flag = 1;
			password = malloc(sizeof(char *)*(length+1));
			strcpy(password,credential);

			flag = query_user_mgmt(username,password,rx,tx);
			if (flag == 0)
			{
				connected_mode(tx, rx, client, username);
			}
			else if (flag == 2)
			{
				goto close;
			}
			else
			{
				goto error_msg;
			}
		}
		count++;
		if (count < 2)
		{
			buffer = "Password : ";
			bytes_received = 11;
			send_tcp_data(rx, tx, buffer, bytes_received);
			buffer = NULL;
			bytes_received = getline(&buffer, &len, rx);
		}	
		else
		{
			goto close;	
		}
	}

error_msg: 
	{
	char data[] = {"Invalid username or password. Goodbye!"};
	send_tcp_data(rx,tx,data,strlen(data));
	goto close;
	}

close:
	if (bytes_received <= 0)
	{
		printf("client closed the connection!\n");
	}

	fclose(tx);
	fclose(rx);

	if (buffer != NULL)
	{
		free(buffer);
	}
	free(username);
	free(password);
	children--;

	return NULL;
}


