#include <stdio.h>
#include "2_threadserver_handle.h"
#include "common.h"
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>

FILE *tx;
FILE *rx;
struct addrinfo *send_addr;

int initialize_user()
{
	struct addrinfo lookup_addr;
	memset(&lookup_addr, 0, sizeof(struct addrinfo));
	lookup_addr.ai_family = AF_UNSPEC;
	lookup_addr.ai_socktype = SOCK_STREAM;
	lookup_addr.ai_protocol = IPPROTO_TCP;

	//struct addrinfo *send_addr;
	if (getaddrinfo("127.0.0.1", "10690", &lookup_addr, &send_addr) != 0)
	{
		#ifdef DEBUG
		perror("getaddrinfo failed");
		#endif
		return 1;
	}

	int sock = socket(send_addr->ai_family, send_addr->ai_socktype,
			send_addr->ai_protocol);
	if (sock < 0)
	{
		#ifdef DEBUG
		perror("socket failed");
		#endif
		return 1;
	}

	if (connect(sock, send_addr->ai_addr, send_addr->ai_addrlen) < 0)
	{
		#ifdef DEBUG
		perror("connect failed");
		#endif
		return 1;
	}
	
	tx = fdopen(sock, "w");
	rx = fdopen(dup(sock),"r");

	return 0;

}

int query_user_mgmt(char username[], char password[],FILE *rx_client, FILE *tx_client)
{
	int status = initialize_user();
	if (status == 1)
	{
		char display[] = "Sorry! User management server unavailable\n";
		send_tcp_data(rx_client, tx_client, display, strlen(display));
		return 2;
	}
	
	server_id = 1;
	size_t bytes_sent = fwrite(&server_id,1,4,tx);
	if (bytes_sent != 4)
	{
		#ifdef DEBUG 
        	perror("sendto failed");
        	#endif
		return 1;
	}
	fflush(tx);
	
	int datalen = sizeof(struct users);
        struct users *tosend = malloc(datalen);
	tosend->online = 1;
	strcpy(tosend->username,username);
	strcpy(tosend->password,password);

	bytes_sent = fwrite(tosend,1,datalen,tx);
	
	if(bytes_sent != (datalen))
        {
        	#ifdef DEBUG 
        	perror("sendto failed");
        	#endif
	        free(tosend);
        	return 1;
	}
	fflush(tx);
	
	char torecv = '\0';
	ssize_t bytes_received = fread(&torecv,1,1,rx);

	if(errno == EPIPE)
        {
		errno = 0;	
		#ifdef DEBUG
		perror("Pipe Error\n");
		#endif
		if (send_addr)
		{
	               	freeaddrinfo(send_addr);
		}
                free(tosend);
		fclose(tx);
		fclose(rx);
        }

	else if(bytes_received <= 0)
        {
        	#ifdef DEBUG
                perror("recvfrom failed\n");
                #endif
                free(tosend);
		fclose(rx);
		fclose(tx);
                return 1;
        }
	else if(bytes_received > 1)
	{
		free(tosend);
		fclose(rx);
		fclose(tx);
        	return 1;
	}
	else
	{
		free(tosend);
		fclose(rx);
		fclose(tx);
        	return 0;
	}
	fclose(rx);
	free(tosend);
	fclose(tx);
	
	return 0;
}
