#ifndef _SERVERFILE_HANDLE_
#define _SERVERFILE_HANDLE_

#include <stdio.h>
#include "common.h"

extern int children;

void register_tcp_handlers();

void send_tcp_data(FILE* rx, FILE *tx, void *data, int datalen);

void prepare_generic_socket(int argc, char *argv[], 
		int family, int flags, int type, int protocol);

void join_all_children();

void receive_multi_tcp_clients();


void *handle_tcp_client(void *arg);

int query_user_mgmt(char username[], char password[],FILE *rx_client, FILE *tx_client);

void connected_mode(FILE *tx, FILE *rx, int client, char username[]);

int initialize_user();

int query_email_or_dropbox(char message[] ,char *port,char username[],int trial, FILE *rx_client, FILE *tx_client);

uint8_t validate_username_password(char username[], char password[]);

void convert_to_uppercase(char message[], uint64_t msg_len);


#endif
